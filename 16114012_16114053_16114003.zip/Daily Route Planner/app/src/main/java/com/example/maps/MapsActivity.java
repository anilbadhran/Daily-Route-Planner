package com.example.maps;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.maps.android.SphericalUtil;

import java.util.ArrayList;
import java.util.Arrays;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
     double d1,d2,d3;
    //private ArrayList<String> d = new ArrayList<>();
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        LatLng A = new LatLng(29.856899, 77.888989);
        LatLng B = new LatLng(30.322150, 78.029834);
        LatLng C = new LatLng(30.129792, 77.266778);
        LatLng D = new LatLng(29.982896, 77.572888);
       // LatLng E = new LatLng(29.970467, 76.880871);
       mMap.addMarker(new MarkerOptions().position(A).title("A")
                .icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.ic_looks_one_black_24dp)));
        mMap.addMarker(new MarkerOptions().position(B).title("B")
        .icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.ic_looks_two_black_24dp)));
        mMap.addMarker(new MarkerOptions().position(C).title("C")
        .icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.ic_looks_3_black_24dp)));
        mMap.addMarker(new MarkerOptions().position(D).title("D")
        .icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.ic_looks_4_black_24dp)));
       mMap.moveCamera(CameraUpdateFactory.newLatLng(A));
       final ArrayList<ArrayList<Double>> dis = new ArrayList<ArrayList<Double>>();
       ArrayList<Double> d =new ArrayList<Double>();
        d.add(SphericalUtil.computeDistanceBetween(A,A));
        d.add(SphericalUtil.computeDistanceBetween(A,B));
        d.add(SphericalUtil.computeDistanceBetween(A,C));
        d.add(SphericalUtil.computeDistanceBetween(A,D));
        dis.add(d);
        d.clear();
        d.add(SphericalUtil.computeDistanceBetween(B,A));
        d.add(SphericalUtil.computeDistanceBetween(B,B));
        d.add(SphericalUtil.computeDistanceBetween(B,C));
        d.add(SphericalUtil.computeDistanceBetween(B,D));
        dis.add(d);
        d.clear();
        d.add(SphericalUtil.computeDistanceBetween(C,A));
        d.add(SphericalUtil.computeDistanceBetween(C,B));
        d.add(SphericalUtil.computeDistanceBetween(C,C));
        d.add(SphericalUtil.computeDistanceBetween(C,D));
        dis.add(d);
        d.clear();
        d.add(SphericalUtil.computeDistanceBetween(D,A));
        d.add(SphericalUtil.computeDistanceBetween(D,B));
        d.add(SphericalUtil.computeDistanceBetween(D,C));
        d.add(SphericalUtil.computeDistanceBetween(D,D));
        dis.add(d);

        d1 = SphericalUtil.computeDistanceBetween(A,B);
        d2 = SphericalUtil.computeDistanceBetween(A,C);
        d3 = SphericalUtil.computeDistanceBetween(C,A);
        final ArrayList<String> arr = new ArrayList<>();
        arr.add(String.valueOf(d1/1000));
        arr.add(String.valueOf(d2/1000));
        arr.add(String.valueOf(d3/1000));

       // Toast.makeText(this, d+"km", Toast.LENGTH_SHORT).show();
       //Toast.makeText(this, d+"km", Toast.LENGTH_SHORT).show();
       // Toast.makeText(this, d3/1000+"km", Toast.LENGTH_SHORT).show();
       // Log.e(tag:"distance" msg:"distance in km = "+distance/1000);

        //calculating shortest path//
        ArrayList<Double> s = new ArrayList<>();

        s.add(dis.get(0).get(1) + dis.get(1).get(2) + dis.get(2).get(3) + dis.get(0).get(3));
        s.add(dis.get(0).get(1) + dis.get(3).get(1) + dis.get(2).get(3) + dis.get(0).get(2));
        s.add(dis.get(0).get(2) + dis.get(1).get(2) + dis.get(3).get(1) + dis.get(0).get(3));
        s.add(dis.get(0).get(2) + dis.get(2).get(3) + dis.get(3).get(1) + dis.get(0).get(1));
        s.add(dis.get(0).get(3) + dis.get(3).get(1) + dis.get(2).get(1) + dis.get(0).get(2));
        s.add(dis.get(0).get(3) + dis.get(2).get(3) + dis.get(2).get(1) + dis.get(0).get(1));

        String ans="";
        double min=0;
        for(int i=0;i<6;i++)
        {
            if(min<s.get(i))min=s.get(i);
        }

        if(min==s.get(0))ans="1-2-3-4-1";
        if(min==s.get(1))ans="1-2-4-3-1";
        if(min==s.get(2))ans="1-3-2-4-1";
        if(min==s.get(3))ans="1-3-4-2-1";
        if(min==s.get(4))ans="1-4-2-3-1";
        if(min==s.get(5))ans="1-4-3-2-1";

        //calculating shortest path//

        btn = (Button) findViewById(R.id.button);
        final String finalAns = ans;
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),Display.class);
              //  i.putExtra("key1",String.valueOf(d1/1000));
               // i.putExtra("key2",String.valueOf(d2/1000));
                i.putExtra("key3", finalAns);
                i.putExtra("key4",dis.get(1));
                startActivity(i);
            }
        });

    }

    private BitmapDescriptor bitmapDescriptorFromVector(Context context,int vectorResId) {
        Drawable vectorDrawable = ContextCompat.getDrawable(context,vectorResId);
        vectorDrawable.setBounds(0,0,vectorDrawable.getIntrinsicWidth(),
                vectorDrawable.getIntrinsicHeight());
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(),
                vectorDrawable.getIntrinsicHeight(),Bitmap.Config.ARGB_8888);
        Canvas canvas =  new Canvas(bitmap);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);

    }

}
