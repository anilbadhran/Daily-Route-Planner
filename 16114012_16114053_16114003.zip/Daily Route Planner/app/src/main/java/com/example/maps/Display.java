package com.example.maps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class Display extends AppCompatActivity {
      TextView t;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        Intent intent = getIntent();
      //  String m1 = intent.getStringExtra("key1");
       // String m2 = intent.getStringExtra("key2");
        String m3 = intent.getStringExtra("key3");
       // Bundle bundle = getIntent().getExtras();
       // ArrayList<String> arr1 = bundle.getStringArrayList("key4");
        t = findViewById(R.id.display_message);
        t.setText(m3+" ");

    }
}
